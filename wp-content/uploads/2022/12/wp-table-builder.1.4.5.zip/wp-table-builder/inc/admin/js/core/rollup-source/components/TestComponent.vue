<template>
	<div></div>
</template>
<script>
export default {
	props: ['label'],
};
</script>
