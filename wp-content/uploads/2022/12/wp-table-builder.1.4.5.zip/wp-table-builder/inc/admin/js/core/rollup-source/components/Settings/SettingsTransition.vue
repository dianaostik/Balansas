<template functional>
	<transition name="wptb-fade" appear>
		<slot></slot>
	</transition>
</template>
