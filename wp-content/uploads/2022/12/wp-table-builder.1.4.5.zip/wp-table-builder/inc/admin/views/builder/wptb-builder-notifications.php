<?php
// if called directly, abort;
if ( ! defined( 'WPINC' ) ) {
	die();
}

?>
<!--this id will be used from context-->
<div id="<?php echo esc_attr( static::FRONTEND_ELEMENT_ID ); ?>">
</div>
