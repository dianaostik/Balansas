<template>
	<div class="wptb-menu-empty-cover">
		<slot></slot>
	</div>
</template>
