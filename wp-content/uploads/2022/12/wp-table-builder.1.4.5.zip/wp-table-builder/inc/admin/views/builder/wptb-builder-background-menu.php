<?php
/**
 * Left panel background menu view.
 */

// if called directly, abort
if ( ! defined( 'WPINC' ) ) {
	die();
}
?>
<div class="wptb-settings-items">
    <div id="wptb-background-menu"></div>
</div>
