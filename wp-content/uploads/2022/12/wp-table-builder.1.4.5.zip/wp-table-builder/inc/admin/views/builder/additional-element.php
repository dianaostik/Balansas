<div class="wptb-element left wptb-draggable-prototype" id="wptb-button">
    <?php require_once NS\WP_TABLE_BUILDER_DIR . 'inc/admin/views/builder/icons/button.php'; ?>
    <p class="wptb-draggable-prototype"><?php esc_html_e( 'Button', 'wp-table-builder' ); ?></p>
</div>
                       